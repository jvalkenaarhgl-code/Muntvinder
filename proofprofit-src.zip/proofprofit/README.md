# Proofset Rendement — v1.0

Een echte Nederlandstalige, offline Android-app voor de inkoop en doorverkoop van Nederlandse proofsets.

## Mogelijkheden

- Bewaar proofsets met jaartal, type, naam, aankoopdatum, status, verkoopdatum en notities.
- Koopprijs, verzendkosten en overige inkoopkosten afzonderlijk invoeren.
- Verkoopprijs, verkoopkosten en platformcommissie invoeren.
- Verkoopduur in dagen, ROI op inkoop, nettomarge op verkoopprijs en winst per dag berekenen.
- Automatisch de break-evenprijs en benodigde verkoopprijs voor een gewenste nettomarge bepalen.
- Dashboard met gerealiseerde en verwachte winst, verzameling en maandgrafiek.
- Proofsets zoeken, filteren, sorteren, bewerken en verwijderen.
- Volledige JSON-back-ups exporteren/importeren en een CSV voor Excel/Sheets exporteren.
- Werkt zonder internet, abonnement of account. Alles staat op het eigen toestel.

## Zo installeer je de APK

Ga in GitHub naar **Actions** → **Proofset Rendement - Android APK** → de nieuwste geslaagde uitvoering → **Proofset-Rendement-APK** bij Artifacts.
Download het zipbestand, pak `app-debug.apk` uit op de Android-telefoon en open het.
Android kan bij de eerste installatie toestemming vragen voor installatie uit deze bron.

De app heeft een **aparte pakketnaam** (`nl.proofset.rendement`) en overschrijft de originele Muntvinder-app niet.

## Als web-app gebruiken

Open de bestanden in `app/src/main/assets/` via een gewone webserver (of de meegeleverde web-ZIP).
Op een HTTPS-domein kan de web-app aan het startscherm worden toegevoegd en offline functioneren.
Bij het openen van `index.html` als lokaal bestand op sommige browsers werken niet alle opslagfuncties; de APK is daarom de aanbevolen versie voor Android.

## Berekeningen

`inkoop_totaal = inkoopprijs + verzendkosten_inkoop + overige_inkoopkosten`

`commissie = rond_af_op_cent(verkoopprijs × commissie_percentage / 100)`

`netto_winst = verkoopprijs − inkoop_totaal − verkoopkosten − commissie`

`ROI (%) = netto_winst / inkoop_totaal × 100`

`nettomarge (%) = netto_winst / verkoopprijs × 100`

`break_even_verkoopprijs = (inkoop_totaal + verkoopkosten) / (1 − commissie_percentage/100)`

`verkoopprijs_voor_doelmarge = (inkoop_totaal + verkoopkosten) / (1 − (commissie_percentage + doelmarge)/100)`

De berekening is een schatting wanneer de proofset nog te koop staat. De app berekent geen fiscale winst en geen correctie voor inflatie of rendement op jaarbasis.

## Lokaal ontwikkelen

Vereist JDK 17, Gradle 8.10.x en Android SDK 35.

```bash
node proofprofit/tests/finance.test.js
gradle -p proofprofit :app:assembleDebug
```

De meeste bestanden zijn geschreven in HTML, CSS en JavaScript zonder externe pakketten. De kleine Java-Androidschil maakt lokaal opslaan/terugzetten van bestanden mogelijk.

## Privacy

Geen inlog, trackers, advertenties of externe server. Android-back-ups zijn bewust uitgeschakeld; maak daarom af en toe handmatig een JSON-back-up en bewaar deze veilig.
