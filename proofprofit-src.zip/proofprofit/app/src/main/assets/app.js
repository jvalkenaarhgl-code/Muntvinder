(function () {
'use strict';
const KEY='proofset_rendement_v1';
const fmtMoney=new Intl.NumberFormat('nl-NL',{style:'currency',currency:'EUR',minimumFractionDigits:2,maximumFractionDigits:2});
const fmtPct=new Intl.NumberFormat('nl-NL',{minimumFractionDigits:1,maximumFractionDigits:1});
const byId=(id)=>document.getElementById(id);
const today=()=>{const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');};
const esc=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const euro=(c)=>fmtMoney.format(c/100);
const pct=(p)=>`${fmtPct.format(p)}%`;
const signed=(c)=>`${c>0?'+':''}${euro(c)}`;
const profitClass=(v)=>v<0?'negative':'positive';
const id=()=>String(Date.now())+'-'+Math.random().toString(36).slice(2,9);
const icon=(key)=>{
 const paths={
  add:'<path d="M12 5v14M5 12h14"/>',
  arrow:'<path d="M7 17 17 7M8 7h9v9"/>',
  bag:'<rect x="4" y="7" width="16" height="15" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0v4"/>',
  money:'<rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 12h.01M18 12h.01"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  download:'<path d="M12 3v12m-4-4 4 4 4-4M4 17v4h16v-4"/>',
  upload:'<path d="M12 16V4m-4 4 4-4 4 4M4 17v4h16v-4"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  edit:'<path d="m4 20 4-.8L20 7a2 2 0 0 0-3-3L5 16z"/>',
  trash:'<path d="M4 7h16M10 4h4M6 7l1 14h10l1-14M10 11v6M14 11v6"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  box:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M9 5v5M15 5v5"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
  filter:'<path d="M4 7h16M7 12h10M10 17h4"/>',
  chart:'<path d="M3 20V10M9 20V4M15 20v-8M21 20V7"/>',
  close:'<path d="M5 5 19 19M19 5 5 19"/>'
 };
 return `<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[key]||paths.info}</svg>`;
};
function load(){try{const data=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(data)?data.filter(r=>r&&typeof r==='object'&&typeof r.id==='string'):[];}catch(e){return [];}}
const state={tab:'dashboard',records:load(),search:'',filter:'all',sort:'recent',calcDraft:{buy:'20',shipping:'3,50',other:'0',sale:'32,50',selling:'0',fee:'0',target:'20',days:'21'}};
let toastTimer=null;
function toast(message){const el=byId('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3300);}
function save(){try{localStorage.setItem(KEY,JSON.stringify(state.records));return true;}catch(e){toast('Opslaan mislukt: controleer de opslagruimte op dit apparaat.');return false;}}
const breakdown=(r)=>Finance.calc(r);
const nameOf=(r)=>r.name?.trim()||`${r.type||'Proofset'} ${r.year||''}`.trim();
const isSold=(r)=>r.status==='sold';
function metrics(){
 let invested=0,realized=0,potential=0,soldCount=0,soldDays=0,activeCount=0;
 for(const r of state.records){const v=breakdown(r);invested+=v.acquisitionCents;if(isSold(r)){realized+=v.profitCents;soldDays+=v.days;soldCount++;}else{potential+=v.profitCents;activeCount++;}}
 return {invested,realized,potential,soldCount,soldDays,activeCount};
}
function panelTitle(title,sub,button){return `<div class="panel-title-row"><div><h2 class="section-heading">${title}</h2><p class="section-caption">${sub}</p></div>${button||''}</div>`;}
function stat(label,value,sub,ic,col,extra=''){
 return `<article class="stat-card"><div class="stat-top"><span class="stat-label">${label}</span><span class="stat-icon ${col||''}">${icon(ic)}</span></div><div class="stat-value ${extra}">${value}</div><div class="stat-sub">${sub}</div></article>`;
}
function renderDashboard(){
 const m=metrics();const top=[...state.records].sort((a,b)=>((isSold(b)?0:1)-(isSold(a)?0:1)) || (String(b.createdAt||'').localeCompare(String(a.createdAt||'')))).slice(0,4);
 return `
 <div class="welcome-head"><div><p class="eyebrow">JOUW VERZAMELING IN BEELD</p><h1 class="page-title">Goed overzicht. Meer rendement.</h1><p class="subhead">Weet precies wat je proofsets je kosten én opleveren.</p></div><button class="soft-btn" data-action="export-json">${icon('download')} Back-up</button></div>
 <section class="hero"><div class="hero-content"><p class="hero-label">SLIM VERZAMELEN & DOORVERKOPEN</p><h2 class="hero-title">Elke set telt.<br>Elke euro ook.</h2><p class="hero-copy">Van aankoop tot verkoop: je winstmarge helder op één plek.</p><button class="hero-btn" data-action="add">＋ &nbsp; Eerste / nieuwe set toevoegen</button></div><div class="hero-orbit"></div><div class="hero-coin" aria-hidden="true">€</div></section>
 <div class="stats-grid">
  ${stat('Totaal ingekocht',euro(m.invested),`${state.records.length} geregistreerde set${state.records.length!==1?'s':''}`,'bag')}
  ${stat('Gerealiseerde winst',signed(m.realized),`${m.soldCount} verkocht`,'money','',profitClass(m.realized))}
  ${stat('Verwachte winst',signed(m.potential),`${m.activeCount} nog niet verkocht`,'chart','gold',profitClass(m.potential))}
  ${stat('Gem. verkoopduur',m.soldCount?`${Math.round(m.soldDays/m.soldCount)} dagen`:'—',m.soldCount?'Van verkochte sets':'Nog geen verkopen','clock')}
 </div>
 <div class="content-grid">
  <section class="panel">${panelTitle('Gerealiseerde winst','Je winst per maand over de laatste 6 maanden')}${renderChart()}</section>
  <section class="panel">${panelTitle('Recente proofsets','Je laatst geregistreerde aankopen',`<button class="text-button" data-nav="collection">Bekijk alle ${icon('arrow')}</button>`)}${top.length?`<div class="mini-list">${top.map(renderMini).join('')}</div>`:empty('Nog geen proofsets','Voeg je eerste aankoop toe. Daarna verschijnt hier je collectie.',true)}</section>
 </div>
 <div class="tips-row"><span>✦</span><div><strong>Een slimme handelaar kijkt naar méér dan winst.</strong><p>Vergelijk ook je rendement op de inkoop en het aantal dagen tot verkoop. Zo weet je of een deal jouw tijd waard is.</p></div></div>`;
}
function renderChart(){
 const now=new Date();const labels=[],values=[];
 for(let i=5;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth()-i,1);labels.push({year:d.getFullYear(),month:d.getMonth(),label:d.toLocaleDateString('nl-NL',{month:'short'}).replace('.','')});values.push(0);}
 for(const r of state.records.filter(isSold)){const d=new Date((r.saleDate||r.createdAt?.slice(0,10)||today())+'T12:00:00');if(Number.isNaN(+d))continue;const idx=labels.findIndex(x=>x.year===d.getFullYear()&&x.month===d.getMonth());if(idx>=0)values[idx]+=breakdown(r).profitCents;}
 if(!state.records.some(isSold))return `<div class="empty-chart">Nog geen verkochte sets.<br>Zodra je een verkoop registreert, zie je hier je winsttrend.</div>`;
 const largest=Math.max(1,...values.map(x=>Math.abs(x)));
 return `<div class="chart-wrap"><div class="chart-bars">${values.map((v,i)=>`<div class="chart-col" title="${esc(labels[i].label)}: ${euro(v)}"><div class="chart-bar ${v<0?'negative':''}" style="height:${Math.max(4,Math.round(Math.abs(v)/largest*96))}%"></div></div>`).join('')}</div><div class="chart-row">${labels.map(x=>`<div class="chart-col"><span class="chart-month">${esc(x.label)}</span></div>`).join('')}</div></div>`;
}
function renderMini(r){const v=breakdown(r);return `<div class="mini-item"><span class="coin-icon small">€</span><div class="mini-body"><p class="mini-title">${esc(nameOf(r))}</p><div class="mini-meta">${isSold(r)?'Verkocht':'Te koop'} · Inkoop ${euro(v.acquisitionCents)}</div></div><div><div class="mini-money">${euro(v.priceCents)}</div><div class="tiny-profit ${v.profitCents<0?'negative':''}">${signed(v.profitCents)}</div></div></div>`;}
function empty(title,desc,small){return `<div class="empty-state"><span class="empty-icon">${small?'◈':'€'}</span><strong>${title}</strong><p>${desc}</p>${small?'<button class="soft-btn" data-action="add">＋ Set toevoegen</button>':''}</div>`;}
function renderCollection(){
 const search=state.search.trim().toLowerCase();let rows=state.records.filter(r=>(state.filter==='all'||(state.filter==='sold'&&isSold(r))||(state.filter==='active'&&!isSold(r)))&&(!search||[r.year,r.type,r.name,r.note].some(v=>String(v||'').toLowerCase().includes(search))));
 rows.sort((a,b)=>{if(state.sort==='profit')return breakdown(b).profitCents-breakdown(a).profitCents;if(state.sort==='roi')return breakdown(b).roi-breakdown(a).roi;if(state.sort==='old')return String(a.createdAt||'').localeCompare(String(b.createdAt||''));return String(b.createdAt||'').localeCompare(String(a.createdAt||''));});
 return `<div class="welcome-head"><div><p class="eyebrow">JOUW HANDELSADMINISTRATIE</p><h1 class="page-title">Mijn proofsets</h1><p class="subhead">Alle aankopen, vraagprijzen en verkopen bij elkaar.</p></div><button class="soft-btn" data-action="export-csv">${icon('download')} CSV exporteren</button></div>
 <div class="collection-summary"><span class="collection-count">${state.records.length} totaal</span><span class="collection-count">${state.records.filter(isSold).length} verkocht</span><span class="collection-count">${state.records.filter(r=>!isSold(r)).length} te koop</span></div>
 <div class="toolbar"><div class="search-control">${icon('search')}<input id="search-records" type="search" placeholder="Zoek op jaartal, type of naam..." value="${esc(state.search)}" aria-label="Proofsets zoeken"></div><select id="filter-records" aria-label="Filter status"><option value="all" ${state.filter==='all'?'selected':''}>Alle statussen</option><option value="active" ${state.filter==='active'?'selected':''}>Te koop</option><option value="sold" ${state.filter==='sold'?'selected':''}>Verkocht</option></select><select id="sort-records" aria-label="Sortering"><option value="recent" ${state.sort==='recent'?'selected':''}>Nieuwste eerst</option><option value="old" ${state.sort==='old'?'selected':''}>Oudste eerst</option><option value="profit" ${state.sort==='profit'?'selected':''}>Hoogste winst</option><option value="roi" ${state.sort==='roi'?'selected':''}>Hoogste ROI</option></select></div>
 ${rows.length?`<div class="records-list">${rows.map(renderRecord).join('')}</div>`:`<div class="empty-collection">${empty(state.records.length?'Geen resultaten':'Begin met je eerste proofset',state.records.length?'Probeer een ander zoekwoord of filter.':'Sla hier je aankopen, verkoopduur en verwachte of gerealiseerde winst op.',!state.records.length)}</div>`}
 <div class="tips-row"><span>↧</span><div><strong>Bewaar je gegevens veilig.</strong><p><button class="text-button" data-action="export-json">Download een volledige JSON-back-up</button> of <button class="text-button" data-action="import-json">importeer een eerdere back-up</button>. Je administratie blijft alleen op dit apparaat.</p></div></div>`;
}
function renderRecord(r){const v=breakdown(r);return `<article class="record-card"><span class="coin-icon">€</span><div class="record-main"><div class="record-title">${esc(nameOf(r))}</div><div class="record-sub"><span class="status ${isSold(r)?'sold':'active'}">${isSold(r)?'✓ Verkocht':'○ Te koop'}</span><span>${v.days} dagen</span><span class="dot-sep"></span><span>${r.year||'Geen jaartal'}</span></div></div><div class="record-financials"><div><span>Inkoop incl. kosten</span><strong>${euro(v.acquisitionCents)}</strong></div><div><span>${isSold(r)?'Verkoopprijs':'Vraagprijs'}</span><strong>${euro(v.priceCents)}</strong></div><div><span>${isSold(r)?'Nettowinst':'Verwachte winst'}</span><strong class="${profitClass(v.profitCents)}">${signed(v.profitCents)}</strong><small style="display:block;color:#94a39a;font-size:10px;margin-top:3px">ROI ${pct(v.roi)}</small></div></div><div class="record-actions"><button class="icon-btn" data-action="edit" data-id="${esc(r.id)}" title="Bewerken" aria-label="Bewerk ${esc(nameOf(r))}">${icon('edit')}</button><button class="icon-btn" data-action="delete" data-id="${esc(r.id)}" title="Verwijderen" aria-label="Verwijder ${esc(nameOf(r))}">${icon('trash')}</button></div></article>`;}
function moneyField(name,label,value,note=''){return `<div class="field"><label for="fld-${name}">${label}</label><div class="input-prefix"><span class="prefix">€</span><input class="field-control" id="fld-${name}" name="${name}" type="text" inputmode="decimal" autocomplete="off" value="${esc(value??'')}" placeholder="0,00"/></div>${note?`<p class="form-hint">${note}</p>`:''}</div>`;}
function otherField(name,label,value,opts={}){const suffix=opts.suffix||'';return `<div class="field ${opts.full?'full':''}"><label for="fld-${name}">${label}</label><div class="${suffix?'input-suffix':''}"><input id="fld-${name}" name="${name}" class="field-control" type="${opts.type||'text'}" inputmode="${opts.mode||'decimal'}" ${opts.type==='number'?'min="1" max="9999" step="1"':''} value="${esc(value??'')}" placeholder="${esc(opts.placeholder||'')}"/>${suffix?`<span class="suffix">${suffix}</span>`:''}</div>${opts.note?`<p class="form-hint">${opts.note}</p>`:''}</div>`;}
function moneyFields(c){return `<div class="form-grid">${moneyField('buy','Aankoopprijs',c.buy)}${moneyField('shipping','Verzending aankoop',c.shipping)}${moneyField('other','Overige inkoopkosten',c.other)}${moneyField('sale','Verwachte verkoopprijs',c.sale)}${moneyField('selling','Verkoopkosten / verzending',c.selling)}${otherField('fee','Platformcommissie',c.fee,{suffix:'%'})}${otherField('days','Verkoopduur',c.days,{suffix:'dagen',note:'Verwachte of daadwerkelijke doorlooptijd.'})}${otherField('target','Gewenste nettomarge',c.target,{suffix:'%',note:'De marge die je minimaal wilt overhouden op de verkoopprijs.'})}</div>`;}
function renderCalculator(){const c=state.calcDraft;return `<div class="welcome-head"><div><p class="eyebrow">BEREKEN VOORDAT JE KOOPT</p><h1 class="page-title">Winstcalculator</h1><p class="subhead">Check direct of een proofset een slimme aankoop is.</p></div><button class="soft-btn" data-action="example">Voorbeeld invullen</button></div>
 <div class="calc-layout"><section class="panel form-panel"><div class="block-heading"><span class="number-badge">01</span> Vul de bedragen in</div><form id="calculator-form" onsubmit="return false">${moneyFields(c)}</form><p class="calc-help">${icon('info')} De inkoop is inclusief verzendkosten. Alle bedragen zijn in euro’s. Een commissie wordt berekend over je verkoopprijs.</p></section>
 <section class="live-panel"><div class="live-content"><div class="live-heading"><span></span> LIVE BEREKENING</div><div class="live-primary-label">Verwachte nettowinst</div><div id="calc-profit" class="live-money">—</div><span id="calc-verdict" class="live-pill">—</span><div class="live-metrics"><div class="live-metric"><span>Rendement op inkoop</span><strong id="calc-roi">—</strong></div><div class="live-metric"><span>Nettomarge op verkoop</span><strong id="calc-margin">—</strong></div><div class="live-metric"><span>Winst per dag</span><strong id="calc-daily">—</strong></div><div class="live-metric"><span>Totale kosten</span><strong id="calc-costs">—</strong></div></div><div class="goal-card"><p>WAT MOET JE MINIMAAL VRAGEN?</p><div class="goal-line"><span>Break-even verkoopprijs</span><strong id="calc-even">—</strong></div><div class="goal-line"><span id="calc-target-label">Voor 20% nettomarge</span><strong id="calc-target">—</strong></div></div><button class="calc-save" data-action="save-calc">＋ &nbsp; Opslaan als proofset</button><p class="live-footnote">Berekend na inkoopkosten, verzendkosten, verkoopkosten en commissie. Dit is een schatting zolang de set niet verkocht is.</p></div></section></div>`;}
function updateCalculator(){const f=byId('calculator-form');if(!f)return;const v=Finance.calc(state.calcDraft);const isNegative=v.profitCents<0;const pr=byId('calc-profit');pr.textContent=signed(v.profitCents);pr.className='live-money '+(isNegative?'red':'green');byId('calc-roi').textContent=pct(v.roi);byId('calc-margin').textContent=pct(v.margin);byId('calc-daily').textContent=euro(v.dailyCents);byId('calc-costs').textContent=euro(v.costsCents);byId('calc-even').textContent=v.breakeven===null?'Niet mogelijk':euro(v.breakeven);byId('calc-target').textContent=v.targetPrice===null?'Niet mogelijk':euro(v.targetPrice);byId('calc-target-label').textContent=`Voor ${pct(v.targetRate)} nettomarge`;byId('calc-verdict').textContent=isNegative?'✕ Verliesgevend bij deze verkoopprijs':v.profitCents===0?'• Je speelt quitte':'✓ Positief resultaat bij deze verkoopprijs';}
function render(){
 const names={dashboard:'JOUW DASHBOARD',collection:'JOUW COLLECTIE',calculator:'WINSTCALCULATOR'};
 byId('breadcrumb').textContent=names[state.tab];document.querySelectorAll('[data-nav]').forEach(b=>b.classList.toggle('selected',b.dataset.nav===state.tab));
 byId('view').innerHTML=state.tab==='dashboard'?renderDashboard():state.tab==='collection'?renderCollection():renderCalculator();
 if(state.tab==='calculator')updateCalculator();
}
function changeTab(tab){if(!['dashboard','collection','calculator'].includes(tab))return;state.tab=tab;render();window.scrollTo({top:0,behavior:'auto'});}
function recordForm(existing,fromCalc){
 const r=existing||{year:new Date().getFullYear(),type:'Proofset',name:'',buy:fromCalc?.buy||'',shipping:fromCalc?.shipping||'0',other:fromCalc?.other||'0',sale:fromCalc?.sale||'',selling:fromCalc?.selling||'0',fee:fromCalc?.fee||'0',target:fromCalc?.target||'20',days:fromCalc?.days||'30',status:'active',buyDate:today(),saleDate:today(),note:''};
 const selected=(t)=>r.type===t?'selected':'';
 byId('modal-root').innerHTML=`<div class="modal-backdrop" id="form-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-label="Proofset ${existing?'bewerken':'toevoegen'}"><div class="modal-head"><div><h2 class="modal-title">${existing?'Proofset bewerken':'Nieuwe proofset toevoegen'}</h2><p class="modal-subtitle">Registreer je aankoop en bereken meteen de winst.</p></div><button type="button" class="modal-close" data-action="close" aria-label="Sluiten">×</button></div><form id="record-form" data-edit-id="${existing?esc(existing.id):''}"><div class="modal-scroll"><div class="form-grid">
 <div class="field"><label for="form-year">Jaartal *</label><input id="form-year" name="year" type="number" min="1900" max="2100" step="1" class="field-control" required value="${esc(r.year)}" /></div><div class="field"><label for="form-type">Type muntset</label><select id="form-type" class="field-control" name="type">${['Proofset','Proofjaarset','Transitieset','Speciale set','Overig'].map(t=>`<option ${selected(t)}>${t}</option>`).join('')}</select></div>
 <div class="field full"><label for="form-name">Naam / omschrijving <span class="field-label-note">optioneel</span></label><input id="form-name" class="field-control" name="name" value="${esc(r.name||'')}" placeholder="Bijv. Proofset Nederland 2016" /></div>
 ${moneyField('buy','Koopprijs *',r.buy)}${moneyField('shipping','Verzendkosten aankoop',r.shipping)}${moneyField('other','Overige inkoopkosten',r.other)}${moneyField('sale','Verkoopprijs *',r.sale)}${moneyField('selling','Kosten bij verkoop',r.selling)}${otherField('fee','Platformcommissie',r.fee,{suffix:'%'})}
 ${otherField('days','Verkoopduur',r.days,{suffix:'dagen'})}${otherField('target','Doelmarge',r.target,{suffix:'%'})}
 <div class="field"><label for="form-buydate">Aankoopdatum</label><input class="field-control" type="date" id="form-buydate" name="buyDate" value="${esc(r.buyDate||today())}" /></div><div class="field" id="sale-date-field"><label for="form-saledate">Verkoopdatum (indien verkocht)</label><input class="field-control" type="date" id="form-saledate" name="saleDate" value="${esc(r.saleDate||today())}" /></div>
 <div class="field full"><label>Status</label><div class="status-select-grid"><label class="status-option"><input type="radio" name="status" value="active" ${!isSold(r)?'checked':''}/> Nog te koop</label><label class="status-option"><input type="radio" name="status" value="sold" ${isSold(r)?'checked':''}/> Verkocht</label></div></div>
 <div class="field full"><label for="form-note">Notities <span class="field-label-note">optioneel</span></label><input id="form-note" class="field-control" name="note" value="${esc(r.note||'')}" placeholder="Bijv. gekocht via Catawiki" /></div></div>
 <div class="modal-preview"><div class="modal-preview-row"><span>Totale inkoopkosten</span><strong id="form-total">—</strong></div><div class="modal-preview-row"><span>Verwachte / gerealiseerde nettowinst</span><b id="form-profit">—</b></div><div class="modal-preview-row"><span>Rendement op inkoop</span><strong id="form-roi">—</strong></div></div>
 </div><div class="modal-foot"><button type="button" class="soft-btn" data-action="close">Annuleren</button><button type="submit" class="btn-primary">${icon('check')} ${existing?'Wijzigingen opslaan':'Proofset opslaan'}</button></div></form></section></div>`;
 const back=byId('form-backdrop');back.addEventListener('click',e=>{if(e.target===back)closeModal();});
 byId('record-form').addEventListener('input',previewForm);byId('record-form').addEventListener('change',previewForm);byId('record-form').addEventListener('submit',submitRecord);previewForm();
 byId('form-year').focus();
}
function formValues(f){const raw=Object.fromEntries(new FormData(f).entries());return {...raw,year:Math.round(Finance.num(raw.year)),days:Math.max(1,Math.round(Finance.num(raw.days)||1)),status:raw.status==='sold'?'sold':'active',buyDate:raw.buyDate||today(),saleDate:raw.saleDate||today()};}
function previewForm(){const f=byId('record-form');if(!f)return;const v=formValues(f),m=breakdown(v);byId('sale-date-field').classList.toggle('hidden',v.status!=='sold');byId('form-total').textContent=euro(m.acquisitionCents);byId('form-profit').textContent=signed(m.profitCents);byId('form-profit').className=profitClass(m.profitCents);byId('form-roi').textContent=pct(m.roi);}
function validateFinancials(r){for(const k of ['buy','shipping','other','sale','selling','fee','target']){if(Finance.num(r[k])<0){toast('Bedragen mogen niet negatief zijn.');return false;}}if(Finance.num(r.fee)>=100||Finance.num(r.target)>=100){toast('Een percentage moet lager dan 100% zijn.');return false;}if(!String(r.buy).trim()||!String(r.sale).trim()){toast('Vul de koopprijs én verkoopprijs in.');return false;}if(r.year<1900||r.year>2100){toast('Controleer het jaartal.');return false;}if(r.days<1||r.days>36500){toast('Vul een verkoopduur tussen 1 en 36.500 dagen in.');return false;}return true;}
function submitRecord(e){e.preventDefault();const f=e.currentTarget,r=formValues(f);if(!validateFinancials(r))return;const editId=f.dataset.editId;const existing=state.records.find(item=>item.id===editId);
 const updated={...r,id:existing?existing.id:id(),createdAt:existing?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};if(existing){state.records=state.records.map(item=>item.id===editId?updated:item);}else{state.records.unshift(updated);}if(!save())return;closeModal();changeTab('collection');toast(existing?'Proofset bijgewerkt':'Proofset opgeslagen');}
function closeModal(){byId('modal-root').innerHTML='';}
function confirmDelete(recordId){const r=state.records.find(x=>x.id===recordId);if(!r)return;byId('modal-root').innerHTML=`<div class="modal-backdrop"><section class="modal" role="alertdialog" aria-modal="true" aria-labelledby="del-head"><div class="delete-prompt"><h2 id="del-head" class="modal-title">Proofset verwijderen?</h2><p>Je verwijdert <strong>${esc(nameOf(r))}</strong> definitief uit je overzicht. Dit kun je alleen herstellen met een eerdere back-up.</p><div class="modal-foot" style="padding:0;border:0"><button class="soft-btn" data-action="close">Annuleren</button><button class="btn-primary" style="background:#b54b50" data-action="confirm-delete" data-id="${esc(recordId)}">Ja, verwijderen</button></div></div></section></div>`;}
function downloadFile(filename,mime,text){
 if(window.NativeBridge && typeof window.NativeBridge.saveFile==='function'){window.NativeBridge.saveFile(filename,mime,text);return;}
 try{const blob=new Blob([text],{type:mime});const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download=filename;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Bestand klaargezet om op te slaan.');}catch(e){toast('Exporteren mislukt.');}
}
function exportJson(){const data={app:'Proofset Rendement',version:1,exportedAt:new Date().toISOString(),records:state.records};downloadFile('proofset-rendement-backup-'+today()+'.json','application/json',JSON.stringify(data,null,2));}
function csvCell(v){const s=String(v??'');const safe=/^[=+\-@\t\r]/.test(s)?"'"+s:s;return '"'+safe.replace(/"/g,'""')+'"';}
function exportCsv(){const header=['Jaar','Type','Naam','Status','Aankoopdatum','Verkoopdatum','Inkoopprijs','Verzendkosten inkoop','Overige inkoopkosten','Inkoop totaal','Verkoopprijs','Verkoopkosten','Commissie %','Commissie bedrag','Nettowinst','ROI %','Nettomarge %','Verkoopduur dagen','Notities'];const lines=[header,...state.records.map(r=>{const v=breakdown(r);return [r.year,r.type,nameOf(r),isSold(r)?'Verkocht':'Te koop',r.buyDate,isSold(r)?r.saleDate:'',Finance.num(r.buy),Finance.num(r.shipping),Finance.num(r.other),Finance.eur(v.acquisitionCents),Finance.num(r.sale),Finance.num(r.selling),Finance.num(r.fee),Finance.eur(v.feeCents),Finance.eur(v.profitCents),v.roi,v.margin,v.days,r.note||''];})];downloadFile('proofset-rendement-'+today()+'.csv','text/csv;charset=utf-8','\ufeff'+lines.map(row=>row.map(csvCell).join(';')).join('\r\n'));}
function importJson(){if(window.NativeBridge&&typeof window.NativeBridge.openFile==='function'){window.NativeBridge.openFile();return;}let input=byId('backup-input');if(!input){input=document.createElement('input');input.id='backup-input';input.type='file';input.accept='.json,application/json';input.style.display='none';document.body.appendChild(input);input.addEventListener('change',async()=>{const file=input.files?.[0];if(file){if(file.size>4_000_000){toast('De back-up is te groot.');input.value='';return;}try{receiveBackup(await file.text());}catch(e){toast('Bestand kon niet worden geopend.');}}input.value='';});}input.click();}
function receiveBackup(data){try{const payload=JSON.parse(data);if(payload.app!=='Proofset Rendement'||!Array.isArray(payload.records))throw Error('Onjuist bestand');const imported=payload.records.filter(r=>r&&typeof r.id==='string'&&typeof r.type==='string'&&r.year>=1900&&r.year<=2100&&['sold','active'].includes(r.status)).slice(0,10000);if(!imported.length){toast('Deze back-up bevat geen geldige proofsets.');return;}const ids=new Set(state.records.map(r=>r.id));let count=0;for(const r of imported){if(!ids.has(r.id)){state.records.push(r);ids.add(r.id);count++;}}if(save()){closeModal();changeTab('collection');toast(count?`${count} proofsets geïmporteerd`:'Alle proofsets stonden al in je app.');}}catch(e){toast('Ongeldige back-up. Kies een export uit deze app.');}}
window.receiveBackup=receiveBackup;
window.appBack=()=>{if(byId('modal-root').innerHTML){closeModal();return true;}if(state.tab!=='dashboard'){changeTab('dashboard');return true;}return false;};
function routeAction(action,el){
 switch(action){
 case 'add':recordForm(null,null);break;
 case 'edit':recordForm(state.records.find(r=>r.id===el.dataset.id),null);break;
 case 'delete':confirmDelete(el.dataset.id);break;
 case 'confirm-delete':state.records=state.records.filter(r=>r.id!==el.dataset.id);if(save()){closeModal();render();toast('Proofset verwijderd');}break;
 case 'close':closeModal();break;
 case 'export-json':exportJson();break;
 case 'export-csv':exportCsv();break;
 case 'import-json':importJson();break;
 case 'save-calc':recordForm(null,state.calcDraft);break;
 case 'example':state.calcDraft={buy:'22,50',shipping:'3,95',other:'0',sale:'34,95',selling:'1',fee:'5',target:'20',days:'14'};render();toast('Voorbeeld ingevuld');break;
 }
}
document.addEventListener('click',e=>{const nav=e.target.closest('[data-nav]');if(nav){changeTab(nav.dataset.nav);return;}const btn=e.target.closest('[data-action]');if(btn){e.preventDefault();routeAction(btn.dataset.action,btn);}});
document.addEventListener('input',e=>{if(e.target.closest('#calculator-form')){state.calcDraft[e.target.name]=e.target.value;updateCalculator();}if(e.target.id==='search-records'){state.search=e.target.value;const start=e.target.selectionStart;const end=e.target.selectionEnd;render();const next=byId('search-records');next.focus();next.setSelectionRange(start,end);}});
document.addEventListener('change',e=>{if(e.target.id==='filter-records'){state.filter=e.target.value;render();}if(e.target.id==='sort-records'){state.sort=e.target.value;render();}});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
if('serviceWorker' in navigator && window.location.protocol==='https:')navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
render();
})();
