/* Proofset Rendement: precieze berekeningen in centen, geen afhankelijkheden. */
(function (root) {
  'use strict';
  function num(v) {
    if (typeof v === 'string') {
      v = v.trim().replace(/\s/g,'').replace('€','');
      if (v.includes(',')) v = v.replace(/\./g, '').replace(',', '.');
    }
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }
  function cents(v) { return Math.round(num(v) * 100); }
  function eur(c) { return c / 100; }
  function pct(v) { return Math.max(0, Math.min(99, num(v))); }
  function calc(s) {
    const buyCents = Math.max(0,cents(s.buy));
    const shippingCents = Math.max(0,cents(s.shipping));
    const otherCents = Math.max(0,cents(s.other));
    const priceCents = Math.max(0,cents(s.sale));
    const sellingCents = Math.max(0,cents(s.selling));
    const feeRate = pct(s.fee);
    const targetRate = pct(s.target);
    const days = Math.max(1, Math.round(num(s.days)||1));
    const acquisitionCents = buyCents + shippingCents + otherCents;
    const feeCents = Math.round(priceCents * feeRate / 100);
    const costsCents = acquisitionCents + sellingCents + feeCents;
    const profitCents = priceCents - costsCents;
    const netSalesCents = priceCents - sellingCents - feeCents;
    const roi = acquisitionCents > 0 ? profitCents/acquisitionCents*100 : 0;
    const margin = priceCents > 0 ? profitCents/priceCents*100 : 0;
    const breakeven = feeRate < 100 ? Math.ceil((acquisitionCents + sellingCents)/(1-feeRate/100)) : null;
    const divisor = 1 - (feeRate+targetRate)/100;
    const targetPrice = divisor > 0 ? Math.ceil((acquisitionCents + sellingCents)/divisor) : null;
    return {buyCents,shippingCents,otherCents,acquisitionCents,priceCents,sellingCents,feeCents,costsCents,profitCents,netSalesCents,roi,margin,breakeven,targetPrice,days,dailyCents:profitCents/days,feeRate,targetRate};
  }
  const api = {num,cents,eur,pct,calc};
  if(typeof module !== 'undefined' && module.exports) module.exports = api;
  root.Finance = api;
})(typeof window !== 'undefined' ? window : globalThis);
