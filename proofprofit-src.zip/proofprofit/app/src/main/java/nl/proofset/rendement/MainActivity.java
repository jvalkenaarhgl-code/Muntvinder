package nl.proofset.rendement;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.view.View;
import android.view.Window;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/** Native, offline Android-app. Geen netwerk of account nodig. */
public class MainActivity extends Activity {
    private static final int SAVE_FILE = 4001;
    private static final int OPEN_FILE = 4002;
    private WebView webView;
    private String pendingExportText;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(246,247,245));
        window.setNavigationBarColor(Color.WHITE);
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(246,247,245));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // De app opent uitsluitend eigen, meegeleverde lokale bestanden.
                return !"file".equalsIgnoreCase(request.getUrl().getScheme());
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new FileBridge(), "NativeBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class FileBridge {
        @JavascriptInterface public void saveFile(String fileName, String mimeType, String text) {
            runOnUiThread(() -> {
                pendingExportText = text;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType.split(";")[0]);
                intent.putExtra(Intent.EXTRA_TITLE, fileName);
                startActivityForResult(intent, SAVE_FILE);
            });
        }
        @JavascriptInterface public void openFile() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, OPEN_FILE);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            pendingExportText = null;
            return;
        }
        Uri uri = data.getData();
        try {
            if (requestCode == SAVE_FILE && pendingExportText != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new java.io.IOException("Geen schrijfrechten");
                    out.write(pendingExportText.getBytes(StandardCharsets.UTF_8));
                }
                jsToast("Back-up opgeslagen op je apparaat.");
            } else if (requestCode == OPEN_FILE) {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new java.io.IOException("Bestand niet te lezen");
                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    byte[] chunk = new byte[8192];
                    int count;
                    while ((count = in.read(chunk)) != -1) {
                        if (buffer.size() + count > 4_000_000) throw new java.io.IOException("Bestand te groot");
                        buffer.write(chunk, 0, count);
                    }
                    String text = buffer.toString(StandardCharsets.UTF_8.name());
                    webView.evaluateJavascript("window.receiveBackup(" + JSONObject.quote(text) + ")", null);
                }
            }
        } catch (Exception ex) {
            jsToast("Bestand lezen of opslaan is mislukt.");
        } finally { pendingExportText = null; }
    }

    private void jsToast(String text) {
        webView.evaluateJavascript("(function(){var t=document.getElementById('toast');if(t){t.textContent=" + JSONObject.quote(text) + ";t.classList.add('show');setTimeout(function(){t.classList.remove('show');},3000)}})()", null);
    }

    @Override public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("window.appBack ? window.appBack() : false", result -> {
            if (!"true".equals(result)) MainActivity.super.onBackPressed();
        });
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
